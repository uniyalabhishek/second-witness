"use strict";
(() => {
  // extension/src/format.ts
  var ENTITIES = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
  function esc(v) {
    return String(v).replace(/[&<>"']/g, (c) => ENTITIES[c]);
  }
  function unit(n, name) {
    return `${n} ${name}${n === 1 ? "" : "s"}`;
  }
  function span(seconds) {
    const s = Math.max(0, Math.floor(Number(seconds) || 0));
    if (s < 60) return unit(s, "second");
    if (s < 3600) return unit(Math.floor(s / 60), "minute");
    if (s < 86400) return unit(Math.floor(s / 3600), "hour");
    return unit(Math.floor(s / 86400), "day");
  }
  var ago = (seconds) => `${span(seconds)} ago`;
  var age = (seconds) => `${span(seconds)} old`;
  var num = (n) => esc(Number(n).toLocaleString("en-US"));
  var count = (n, one, many = `${one}s`) => `${num(n)} ${n === 1 ? one : many}`;
  var RESULTS = {
    matches: { slug: "matches", sign: "=", word: "Matches", head: "Same code" },
    changed: { slug: "changed", sign: "\u2260", word: "Changed", head: "Don't sign" },
    notSeen: { slug: "not-seen", sign: "?", word: "Not seen", head: "Not seen" },
    newRelease: { slug: "new-release", sign: "+", word: "New release", head: "New release" },
    partial: { slug: "partial", sign: "\u2248", word: "Partial", head: "Partial" },
    cantCheck: { slug: "cant-check", sign: "\u2205", word: "Can't check", head: "Can't check" }
  };
  var resultOf = (kind) => RESULTS[kind] ?? RESULTS.cantCheck;
  function inline(kind, as = "word") {
    const r = resultOf(kind);
    return `<span class="result-inline" data-result="${r.slug}"><span class="result-sign" aria-hidden="true">${r.sign}</span>${r[as]}</span>`;
  }
  var MAX_TAIL = 28;
  function value(v, kind = "plain") {
    const s = String(v);
    const slash = kind === "path" ? s.lastIndexOf("/") : -1;
    const cut = slash >= 0 ? Math.max(slash, s.length - MAX_TAIL) : Math.max(0, s.length - 8);
    const cls = kind === "hash" ? "value value--hash" : "value";
    return `<button type="button" class="${cls}" data-copy="${esc(s)}" title="${esc(s)}"><span class="value-head">${esc(s.slice(0, cut))}</span><span class="value-tail">${esc(s.slice(cut))}</span></button>`;
  }
  function installCopy() {
    document.addEventListener("click", (e) => {
      const v = e.target.closest("[data-copy]");
      if (!v) return;
      navigator.clipboard?.writeText(v.dataset.copy ?? "");
      v.dataset.copied = "";
      setTimeout(() => delete v.dataset.copied, 1500);
    });
  }

  // core/src/types.ts
  var NEW_RELEASE_SECONDS = 72 * 3600;
  var MIN_WITNESSES = 2;

  // extension/src/render.ts
  var IDLE_NOTE = "Attaches Chrome's debugger to this tab until you press Finish. The comparison runs in this browser.";
  var DEBUGGER_BAR = "Chrome shows a debugger bar until you finish.";
  var shell = (host, body) => `<section class="popup"><p class="popup-host mono">${esc(host)}</p>${body}</section>`;
  var head = (kind, text) => {
    const r = resultOf(kind);
    return `<div class="result" data-result="${r.slug}" role="status"><h1 class="result-head"><span class="result-sign" aria-hidden="true">${r.sign}</span><span>${r.head}</span></h1><p class="result-text">${text}</p></div>`;
  };
  var foot = (line) => `<footer class="popup-foot"><p class="small quiet">${line}</p><button type="button" class="button button--quiet" data-action="finish">Finish</button></footer>`;
  var row = (label, html) => `<div class="row"><dt>${label}</dt><dd>${html}</dd></div>`;
  var rows = (items, gap = false) => items.length ? `<dl class="popup-rows${gap ? " popup-rows--gap" : ""}">${items.join("")}</dl>` : "";
  var note = (text) => `<p class="popup-note small">${text}</p>`;
  function list(title, items, first = false) {
    const lis = items.map((i) => `<li>${i}</li>`).join("");
    return `<div class="popup-list${first ? " popup-list--first" : ""}"><h2 class="list-title">${title}</h2><ul class="list">${lis}</ul></div>`;
  }
  var records = (seconds) => seconds === null ? "Witness records have not been read yet." : `Witness records updated ${esc(ago(seconds))}.`;
  var numText = (html) => `<span class="num">${html}</span>`;
  var uncomparedCount = (v) => {
    const u = v.uncompared;
    return u.inline + u.eval + u.wasm + u.frames + u.thirdParty.length;
  };
  var witnessesBehind = (v) => v.freshWitnesses < MIN_WITNESSES;
  var BEHIND = `Fewer than ${MIN_WITNESSES} witnesses checked this site in the last hour.`;
  var NO_FILES = "No first-party files were compared.";
  var DISPUTED = "One witness recorded a different version of a file whose name promises fixed content.";
  var SO_DO = "Tell the other signers. Check again from another device.";
  var disputedOf = (v) => v.disputed ?? [];
  var extensionNote = ({ extensionScripts: n }) => !n ? "" : ` ${n === 1 ? "1 from a browser extension" : `${num(n)} from browser extensions`}, not compared.`;
  var comparedRow = (v, scriptsSeen) => row("Compared", numText(`${count(v.filesCompared, "file")} from ${count(scriptsSeen, "script")}.${extensionNote(v)}`));
  function witnessesRow(v) {
    const latest = v.lastCheckedSeconds === null ? "" : `, latest ${esc(ago(v.lastCheckedSeconds))}`;
    return row("Witnesses", `${count(v.freshWitnesses, "witness", "witnesses")} checked in the last hour${latest}`);
  }
  function notSeenText({ notSeen, unknownHosts: { length: hosts } }) {
    const files = "Don't sign yet. Two witnesses have not recorded this code. New files usually clear within 30 minutes.";
    if (hosts === 0) return `${files} This updates on its own, no reload needed.`;
    if (notSeen.length > 0) return `${files} ${hosts === 1 ? "A host not on this site's list stays" : "Hosts not on this site's list stay"} until the list is updated.`;
    const opening = hosts === 1 ? "A script here comes from a host" : `Scripts here come from ${num(hosts)} hosts`;
    return `${opening} not on this site's list. Check ${hosts === 1 ? "it" : "them"} before signing. Witnesses only record the site's own files, so this stays until the list is updated.`;
  }
  function notSeenEvidence(v) {
    const files = v.notSeen.length === 1 ? "First-party file" : `First-party files, ${num(v.notSeen.length)}`;
    const hosts = v.unknownHosts.length === 1 ? "Host not on this site's list" : `Hosts not on this site's list, ${num(v.unknownHosts.length)}`;
    return (v.notSeen.length ? list(files, v.notSeen.map((p) => value(p, "path"))) : "") + (v.unknownHosts.length ? list(hosts, v.unknownHosts.map((h) => value(h))) : "");
  }
  function releaseRow(v) {
    const r = v.release;
    const seen = v.witnessCount > 0 ? `, seen by ${count(v.witnessCount, "witness", "witnesses")}` : "";
    return row("Released", `${esc(ago(r.ageSeconds))}${seen}`);
  }
  var andMore = (total, listed) => total > listed ? [numText(`and ${num(total - listed)} more`)] : [];
  function releaseLists(v) {
    const r = v.release;
    const inUrl = r.addrs.filter((a) => a.inTabUrl);
    const others = r.addrs.filter((a) => !a.inTabUrl);
    const othersTotal = r.totals.addrs - inUrl.length;
    let html = "";
    if (inUrl.length) html += list("Added, and in this tab's URL", inUrl.map((a) => value(a.value)), true);
    if (othersTotal > 0) {
      const title = `${inUrl.length ? "Also added" : "Added"}, ${count(othersTotal, "address", "addresses")}`;
      html += list(title, [...others.map((a) => value(a.value)), ...andMore(othersTotal, others.length)]);
    }
    if (r.totals.hosts > 0) {
      html += list(`Added, ${count(r.totals.hosts, "host")}`, [...r.hosts.map((h) => value(h.value)), ...andMore(r.totals.hosts, r.hosts.length)]);
    }
    return html;
  }
  function partialLists(v) {
    const u = v.uncompared;
    const items = [];
    if (u.inline) items.push(numText(count(u.inline, "inline script")));
    if (u.eval) items.push(numText(count(u.eval, "eval script")));
    if (u.wasm) items.push(numText(count(u.wasm, "WebAssembly module")));
    if (u.frames) items.push(numText(count(u.frames, "frame or worker", "frames or workers")));
    const disputed = disputedOf(v);
    const title = disputed.length === 1 ? "File one witness recorded differently" : `Files one witness recorded differently, ${num(disputed.length)}`;
    return (disputed.length ? list(title, disputed.map((p) => value(p, "path"))) : "") + (items.length ? list("Not compared", items) : "") + (u.thirdParty.length ? list(`Scripts from ${count(u.thirdParty.length, "listed host")}`, u.thirdParty.map((t) => value(t.host))) : "");
  }
  function also(kind, evidence) {
    return rows([row("Also", inline(kind))], true) + evidence;
  }
  function otherReasons(v) {
    let html = "";
    if (v.result !== "notSeen" && (v.notSeen.length || v.unknownHosts.length)) html += also("notSeen", notSeenEvidence(v));
    if (v.result !== "newRelease" && v.release) html += also("newRelease", rows([releaseRow(v)]) + releaseLists(v));
    if (v.result !== "partial" && (uncomparedCount(v) || disputedOf(v).length || witnessesBehind(v) || v.filesCompared === 0)) {
      const notes = (witnessesBehind(v) ? note(BEHIND) : "") + (v.filesCompared === 0 ? note(NO_FILES) : "");
      html += also("partial", partialLists(v) + notes);
    }
    return html;
  }
  function changedText(v) {
    const n = v.changed.length;
    if (v.changed.some((c) => !c.witnessedHashes.includes(c.tabHash))) return "This tab is running different code from what everyone else got.";
    if (n > 1) return `Witnesses recorded more than one version of ${num(n)} files whose names promise fixed content.`;
    return v.changed[0]?.original ? "This file's name promises fixed content, and witnesses recorded a changed version in the last 72 hours. This tab has the original, but the site has served different code." : "This file's name promises fixed content, and this tab is running a changed version.";
  }
  var hashes = (list2) => list2.map((h) => value(h, "hash")).join("<br>");
  function sizeRow(c) {
    const e = c.evidence;
    if (!e || e.newHash !== c.tabHash) return "";
    const diff = e.sizes[1] - e.sizes[0];
    if (diff === 0) return row("Size", numText("Same size in this tab"));
    return row("Size", numText(`${count(Math.abs(diff), "byte")} ${diff > 0 ? "larger" : "smaller"} in this tab`));
  }
  function changedFile(c) {
    const others = c.witnessedHashes.filter((h) => h !== c.tabHash);
    const bothWitnessed = c.witnessedHashes.includes(c.tabHash);
    const region = c.evidence?.region ?? null;
    const items = [
      row("File", value(c.path, "path")),
      row("This tab", value(c.tabHash, "hash")),
      row(bothWitnessed ? "Other" : "Witnesses", hashes(others)),
      sizeRow(c)
    ];
    const noRegion = bothWitnessed ? "Witnesses kept no changed region for this file." : "Witnesses never recorded this version, so there is no changed region to show.";
    if (region === null) return rows([...items, row("Region", noRegion)]);
    return rows(items) + `<div class="popup-list"><h2 class="list-title">Witnessed change, block ${num(c.evidence.createdAtBlock)}</h2></div><pre class="region popup-region" tabindex="0">${esc(region)}</pre>`;
  }
  function matchesText(v) {
    const newest = v.newestFileAgeSeconds === null ? "" : ` Newest file ${esc(age(v.newestFileAgeSeconds))}.`;
    return `This tab is running what everyone else got.${newest}`;
  }
  function newReleaseText(v) {
    const { ageSeconds, totals: { addrs, hosts } } = v.release;
    if (!addrs && !hosts) return `Witnesses first saw this code ${esc(ago(ageSeconds))}, and it added no addresses or hosts. This clears after an hour.`;
    let what;
    if (addrs && hosts) what = `${addrs === 1 ? "an address" : "addresses"} and ${hosts === 1 ? "a host" : "hosts"}`;
    else if (hosts) what = count(hosts, "host");
    else what = count(addrs, "address", "addresses");
    return `Witnesses saw this code. Its release added ${what} in the last 72 hours. Check what it added before signing.`;
  }
  function partialText(v) {
    const parts = [v.filesCompared > 0 ? `${count(v.filesCompared, "file")} ${v.filesCompared === 1 ? "matches" : "match"} ${count(v.witnessCount, "witness", "witnesses")}.` : NO_FILES];
    if (disputedOf(v).length) parts.push(DISPUTED);
    if (uncomparedCount(v)) parts.push("Other code is running here that was not compared.");
    if (witnessesBehind(v)) parts.push(BEHIND);
    return parts.join(" ");
  }
  var CANT_CHECK = {
    siteNotListed: "This site isn't on the witness list, so there is nothing to compare with.",
    catalogueStale: "The witness records in this browser are too old. They need to be under 1 hour old.",
    noRoster: `The witness roster on ${value("secondwitness.eth")} can't be read right now, so no record can be counted.`,
    noCatalogue: "The witness records haven't reached this browser yet, so there is nothing to compare with."
  };
  function attached({ host, verdict: v, scriptsSeen, updatedAt }, now) {
    const updated = `Updated ${esc(ago((now - updatedAt) / 1e3))}. ${DEBUGGER_BAR}`;
    const compared = comparedRow(v, scriptsSeen);
    const body = () => {
      switch (v.result) {
        case "matches":
          return head("matches", matchesText(v)) + rows([compared, witnessesRow(v)]);
        case "changed":
          return head("changed", changedText(v)) + note(SO_DO) + v.changed.map(changedFile).join("");
        case "notSeen":
          return head("notSeen", notSeenText(v)) + rows([compared]) + notSeenEvidence(v);
        case "newRelease":
          return head("newRelease", newReleaseText(v)) + rows([releaseRow(v), compared]) + releaseLists(v);
        case "partial":
          return head("partial", partialText(v)) + rows(witnessesBehind(v) ? [compared, witnessesRow(v)] : [compared]) + partialLists(v);
        default:
          return null;
      }
    };
    const main = body();
    if (main === null) {
      const reason = v.cantCheckReason ?? "noCatalogue";
      const line = reason === "siteNotListed" ? updated : `Retrying every 60 seconds. ${DEBUGGER_BAR}`;
      return shell(host, head("cantCheck", CANT_CHECK[reason] ?? CANT_CHECK.noCatalogue) + foot(line));
    }
    return shell(host, main + otherReasons(v) + foot(updated));
  }
  function render(state, now) {
    if (state.phase === "attached") return attached(state, now);
    if (state.phase === "checking") {
      return shell(
        state.host,
        `<div class="popup-checking" role="status"><p class="popup-count num">Hashing ${num(state.hashed)} of ${count(state.total, "script")}</p><p class="small quiet">No result yet. ${records(state.catalogueAgeSeconds)}</p></div>` + foot(`Started ${esc(ago((now - state.startedAt) / 1e3))}. ${DEBUGGER_BAR}`)
      );
    }
    if (!state.listed) {
      return shell(state.host, head("cantCheck", CANT_CHECK.siteNotListed) + '<p class="popup-note popup-last small quiet">The debugger was not attached.</p>');
    }
    const last = state.lastCheck;
    const intro = last ? `Last check: ${inline(last.result)}, ${esc(ago((now - last.finishedAt) / 1e3))}. Code loaded since then was not compared.` : "Check the code in this tab against what everyone else got.";
    return shell(
      state.host,
      `<div class="popup-idle"><p>${intro}</p><button type="button" class="button popup-primary" data-action="start">Check before signing</button>${state.attachFailed ? `<p class="small">Chrome would not attach the debugger to this tab, so nothing was compared. Close other debugging tools and try again.</p>` : ""}<p class="small quiet">${IDLE_NOTE} ${records(state.catalogueAgeSeconds)}</p></div>`
    );
  }
  function renderUnavailable() {
    return `<section class="popup">${head("cantCheck", "The extension's background worker did not answer, so nothing was compared.")}<div class="popup-last"></div></section>`;
  }

  // extension/src/popup.ts
  var app = document.getElementById("app");
  var tabId = Number(new URLSearchParams(location.search).get("tab")) || void 0;
  async function refresh() {
    try {
      const state = await chrome.runtime.sendMessage({ type: "getState", tabId });
      app.innerHTML = state ? render(state, Date.now()) : renderUnavailable();
    } catch {
      app.innerHTML = renderUnavailable();
    }
  }
  app.addEventListener("click", async (e) => {
    const action = e.target.closest("[data-action]")?.dataset.action;
    if (!action) return;
    try {
      await chrome.runtime.sendMessage({ type: action, tabId });
    } finally {
      await refresh();
    }
  });
  installCopy();
  chrome.storage.onChanged.addListener(() => void refresh());
  void refresh();
})();
